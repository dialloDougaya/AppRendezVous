module.exports = {
  root: true,
  extends: require.resolve('@fullcalendar/standard-scripts/config/eslint.pkg.browser.cjs'),
}
