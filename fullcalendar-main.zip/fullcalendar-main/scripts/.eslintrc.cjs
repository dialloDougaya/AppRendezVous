
module.exports = {
  root: true,
  extends: ['./config/eslint.pkg.node.cjs'],
}
