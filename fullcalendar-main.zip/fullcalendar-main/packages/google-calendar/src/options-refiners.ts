
export const OPTION_REFINERS = {
  googleCalendarApiKey: String,
}
